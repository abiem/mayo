//
//  Mayo-ios-client-Bridging-Header.h
//  Mayo-ios-client
//
//  Created by abiem  on 4/16/17.
//  Copyright © 2017 abiem. All rights reserved.
//

#ifndef Mayo_ios_client_Bridging_Header_h
#define Mayo_ios_client_Bridging_Header_h

#import "OnboardingViewController.h"
#endif /* Mayo_ios_client_Bridging_Header_h */
