# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* We're working on bringing the world closer together in-person with Mayo. 
* For more info, get in touch with us! hello@heymayo.com
* Version: Beta

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Allen Chan — allen@heymayo.com
